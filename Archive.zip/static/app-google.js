(()=> {
  // MCPP sentinel: edit_path_ok_v1

  "use strict";

/*
====================================================================
 Magic City Vendor Map — Planned File Split (for later extraction)
--------------------------------------------------------------------
core-state.js      → Elements, app state, role toggles, small UI helpers
utils-geo.js       → Projection accessors, geometry & math, styling helpers
ui-list.js         → List rendering, search, CSV/JSON export
draw-overlays.js   → Booth polygon/label/rotation knob/debug drawing & sync
controls.js        → DOM events, admin/viewer toggles, keyboard nudges
map-init.js        → Map boot, OverlayView projection, first render hooks
badges.js          → Vendor Logo Badges (Advanced Markers overlay)
====================================================================
*/


  // ⬇️ Advanced Marker content: zero-sized wrapper anchors center, not top-left
  function makeRotatorContent(){
    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'position:relative;width:0;height:0;';

    const knob = document.createElement('div');
    knob.style.cssText = [
      'position:absolute','left:50%','top:50%',
      'width:22px','height:22px','display:grid','place-items:center',
      'border-radius:50%','background:#0a1514',
      'border:1px solid #2b4e4c','box-shadow:0 0 2px rgba(0,0,0,.5)',
      'cursor:grab','transform:translate(-50%,-50%)'
    ].join(';');

    knob.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 22 22">
      <path d="M11 2.5a8.5 8.5 0 0 1 7.7 4.9" stroke="#d6ff2e" stroke-width="2.2" fill="none" />
      <path d="M18.7 5.6l-2.8 0.5 1.2-2.5z" fill="#d6ff2e"/>
      <path d="M11 19.5a8.5 8.5 0 0 1-7.7-4.9" stroke="#d6ff2e" stroke-width="2.2" fill="none" />
      <path d="M3.3 16.4l2.8-0.5-1.2 2.5z" fill="#d6ff2e"/>
    </svg>`;

    wrapper.appendChild(knob);
    return wrapper;
  }

  // #region Core — Elements & State
  // Split target: core-state.js — elements, app state, role toggles, basic UI helpers
  // ===== Elements =====
  const $ = (id) => document.getElementById(id);
  const els = {
    profileBtn: $('profileBtn'), profileMenu: $('profileMenu'), loginBtn: $('loginBtn'), logoutBtn: $('logoutBtn'),
    roleBadge: $('roleBadge'), adminBar: $('adminBar'),
    addr: $('addr'), locate: $('locate'), fit: $('fit'), toggleType: $('toggleType'),
    defWidth: $('defWidth'), defLength: $('defLength'), defCat: $('defCat'),
    addBooth: $('addBooth'), duplicateBooth: $('duplicateBooth'),
    exportCSV: $('exportCSV'), exportJSON: $('exportJSON'),
    drawer: $('drawer'), panels: $('panels'), listPanel: $('listPanel'), boothList: $('boothList'), listSearch: $('listSearch'),
    editPanel: $('editPanel'), legendPanel: $('legendPanel'), backToList: $('backToList'),
    boothId: $('boothId'), widthFeet: $('widthFeet'), lengthFeet: $('lengthFeet'), rotationDeg: $('rotationDeg'), category: $('category'),
    logoUrl: $('logoUrl'), logoPreview: $('logoPreview'), biz: $('biz'), vendorName: $('vendorName'),
    phone: $('phone'), phonePublic: $('phonePublic'), email: $('email'), emailPublic: $('emailPublic'),
    website: $('website'), notes: $('notes'),
    assign: $('assign'), unassign: $('unassign'), deleteBooth: $('deleteBooth')
  };

  // ===== State =====
  const S = {
    isAdmin:false, map:null, geocoder:null,
    booths:{}, shapes:{}, selected:null, seq:1,
    saveTimer:null, didInitialViewport:false,
    draggingRot:false, draggingBoothId:null, rotMoveListener:null,
    proj:null
  };
  window.S = S;
  const hasMapId = !!(window.__MAP_ID__ && String(window.__MAP_ID__).trim());
  let canAdv = false;

  // #region Utilities =====
  // Split target: utils-geo.js — projection/math/styling helpers
  // ---- Common helpers (consolidated) ----
  function projReady(){
    return !!(S && S.proj && typeof S.proj.getProjection === 'function' && S.proj.getProjection());
  }
  function projection(){
    return projReady() ? S.proj.getProjection() : null;
  }
  function setPos(target, pos){
    if (!target || !pos) return;
    if (canAdv && 'position' in target) target.position = pos;
    else if (typeof target.setPosition === 'function') target.setPosition(pos);
  }

  // Centralize rotation handle show/hide and draggability
  function setRotVisibility(rot, show){
    if (!rot) return;
    const on = !!show;
    // Advanced Marker knob
    if (rot.content && rot.content.style){
      rot.content.style.display = on ? '' : 'none';
      try { rot.gmpDraggable = on; } catch(_) {}
    }
    // Classic Marker fallback (shimmed .element)
    if (rot.element && rot.element.style){
      rot.element.style.display = on ? '' : 'none';
      try { if (rot.setDraggable) rot.setDraggable(on); } catch(_) {}
    }
  }
  function postViewportSync(){
    // Re-center labels/knobs and apply zoom-dependent styling in one place
    requestAnimationFrame(()=>{
      try { syncOverlayCenters(); } catch(_){}
      try { updateLabelVisibility(); } catch(_){}
      try { updateLabelLayoutForZoom(); } catch(_){}
      try { if (window.mcppLogoBadges && typeof window.mcppLogoBadges.refresh === 'function') window.mcppLogoBadges.refresh(); } catch(_){}
    });
  }
  const ccwToCw = (deg)=> ((-deg % 360)+360)%360; // stored CCW -> CW display angle

  function showBootError(msg){
    const bar=document.createElement('div');
    bar.style.cssText='position:fixed;left:0;right:0;top:52px;z-index:9999;padding:10px 14px;background:#3b1a1a;color:#ffdede;border-bottom:1px solid #732;font:14px/1.35 system-ui,sans-serif';
    bar.textContent='Map failed to initialize: '+msg;
    document.body.appendChild(bar);
  }
  function roleBadge(){ els.roleBadge && (els.roleBadge.textContent = S.isAdmin ? 'Admin' : 'Viewer'); }

  function showList(){
    els.panels&&els.panels.classList.add('mode-list');
    els.panels&&els.panels.classList.remove('mode-edit');
    els.drawer&&els.drawer.classList.add('open');
  }
  function showEditor(){
    els.panels&&els.panels.classList.remove('mode-list');
    els.panels&&els.panels.classList.add('mode-edit');
    els.drawer&&els.drawer.classList.add('open');
    els.editPanel && els.editPanel.classList.remove('hidden');
    els.editPanel && (els.editPanel.scrollTop = 0);
    els.legendPanel && els.legendPanel.classList.add('hidden');
  }
  function resetToListPanel(){
    if(S.selected){
      Object.entries(S.shapes).forEach(([bid,sh])=>{
        const bb=S.booths[bid];
        const assigned=!!(bb.biz||bb.vendor_name||bb.notes||(bb.phone||bb.email));
        const st=style(bb.category||'standard',assigned);
        sh.rot&&sh.rot.element&&(sh.rot.element.style.display='none');
        sh.poly&&sh.poly.setOptions({strokeColor:st.stroke,strokeWeight:1,fillOpacity:.75});
        sh.labelEl&&(sh.labelEl.style.color='#eaf6f5');
      });
    }
    S.selected=null;
    // Also clear Booth # when returning to list panel
    if (els.boothId) {
      try {
        if (typeof els.boothId.textContent === 'string') els.boothId.textContent = '—';
        if ('value' in els.boothId) els.boothId.value = '';
      } catch(_) {}
    }
    els.panels&&els.panels.classList.add('mode-list');
    els.panels&&els.panels.classList.remove('mode-edit');
    els.drawer&&els.drawer.classList.add('open');
    els.editPanel&&els.editPanel.classList.add('hidden');
    els.legendPanel&&els.legendPanel.classList.add('hidden');
    S.map&&S.map.setOptions({keyboardShortcuts:true});
    refreshList();
  }

  function setRO(readOnly){
    // Keep the toolbar visible in both modes; per-control visibility handled below
    if (els.adminBar) els.adminBar.classList.remove('hidden');
    [els.biz,els.vendorName,els.phone,els.email,els.website,els.notes,els.category,els.widthFeet,els.lengthFeet,els.rotationDeg,els.logoUrl]
      .forEach(el=>{ if(!el) return; el.disabled=readOnly; if(el.tagName==='TEXTAREA') el.readOnly=readOnly; });

    // Toggle admin-only vs viewer-only UI elements
    document.querySelectorAll('.admin-only').forEach(el => {
      el.style.display = readOnly ? 'none' : '';
    });
    document.querySelectorAll('.viewer-only').forEach(el => {
      el.style.display = readOnly ? '' : 'none';
    });
    updateCategoryPill();

    const labelOf = (el)=> el ? (el.closest ? el.closest('label') : (function(n){while(n&&n.tagName!=='LABEL'){n=n.parentElement;}return n;})(el)) : null;
    [labelOf(els.widthFeet), labelOf(els.lengthFeet), labelOf(els.rotationDeg), labelOf(els.logoUrl)]
      .forEach(l=>{ if(l) l.style.display = readOnly ? 'none' : ''; });

    const actions=document.querySelector('.actions-bottom'); actions&&(actions.style.display=readOnly?'none':'');
    const pLbl=els.phonePublic?(els.phonePublic.closest?els.phonePublic.closest('label'):els.phonePublic.parentElement):null;
    const eLbl=els.emailPublic?(els.emailPublic.closest?els.emailPublic.closest('label'):els.emailPublic.parentElement):null;
    pLbl&&(pLbl.style.display=readOnly?'none':'flex'); eLbl&&(eLbl.style.display=readOnly?'none':'flex');

    const phoneRow=document.getElementById('phoneRow'), emailRow=document.getElementById('emailRow');
    if(readOnly){
      const b=S.selected?S.booths[S.selected]:null;
      phoneRow&&(phoneRow.style.display=(b&&b.phone_public)?'':'none');
      emailRow&&(emailRow.style.display=(b&&b.email_public)?'':'none');
    } else { phoneRow&&(phoneRow.style.display=''); emailRow&&(emailRow.style.display=''); }

    // Ensure primary map controls are always visible and enabled in Viewer mode
    ['addr','locate','fit','toggleType'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.style.display = '';
      el.disabled = false;
    });

    Object.values(S.shapes).forEach(sh=>{
      if (sh.poly && typeof sh.poly.setDraggable === 'function') {
        sh.poly.setDraggable(!readOnly);
      }
      if (sh.rot) {
        // Always hide the rotation handle in viewer mode
        sh.rot.draggable = false;
        if (sh.rot.element) sh.rot.element.style.display = readOnly ? 'none' : (S.selected && S.isAdmin ? '' : 'none');
      }
    });
  }
  // #endregion Core — Elements & State

  async function who(){ try{ const r=await fetch('/whoami'); const j=await r.json(); S.isAdmin=!!j.is_admin; }catch{ S.isAdmin=false; } roleBadge(); if (els.loginBtn) els.loginBtn.textContent = S.isAdmin ? 'Logout' : 'Login'; setRO(!S.isAdmin); resetToListPanel(); }
  async function load(){ try{ const r=await fetch('/api/vendors'); if(r.ok) S.booths=await r.json(); }catch{ S.booths={}; }
    Object.values(S.booths).forEach(b=>{
      if (b.size_feet) { b.width_feet = b.length_feet = b.size_feet; delete b.size_feet; }
      if (b.rotation_deg == null) b.rotation_deg = 0;
      b.category = normalizeCategoryKey(b.category || 'standard');
    });
    let mx=0; Object.keys(S.booths).forEach(id=>{ const n=parseInt((id.match(/\d+/)||[0])[0],10); if(n>mx) mx=n; }); S.seq=mx+1;
  }
  async function save(debounce=true){
    clearTimeout(S.saveTimer);
    const go=async()=>{ if(!S.isAdmin) return;
      try{
        const r=await fetch('/api/vendors',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(S.booths)});
        if(!r.ok){ console.warn('Save failed', r.status, await r.text()); }
        refreshList();
      }catch(e){ console.warn('Save error', e); }
    };
    if(debounce) S.saveTimer=setTimeout(go,350); else await go();
  }

  // #endregion Utilities =====
  
  // #region Geometry helpers =====
  // Split target: utils-geo.js — rectangle math, rotations, style mapping
  function d2ll(lat0,dx,dy){ const dLat=dy/111320, dLng=dx/(111320*Math.cos(lat0*Math.PI/180)); return {lat:lat0+dLat, dLng}; }
  function rot(dx,dy,a){ const t=a*Math.PI/180,c=Math.cos(t),s=Math.sin(t); return [dx*c-dy*s, dx*s+dy*c]; }
  function rect(c,wf,lf,a){
    const w=wf*FT, l=lf*FT, hw=w/2, hl=l/2, lat0=c.lat, lng0=c.lng, base=[[-hw,-hl],[hw,-hl],[hw,hl],[-hw,hl]];
    return base.map(([x,y])=>rot(x,y,a)).map(([x,y])=>{ const {lat,dLng}=d2ll(lat0,x,y); return new google.maps.LatLng(lat,lng0+dLng); });
  }
  function style(cat, assigned){
    const s = CAT[cat] || CAT.standard;
    return { fill: assigned ? s.f : '#0a1514', stroke: s.s };
  }

  // #endregion Geometry helpers =====
  
  // #region Category helpers: normalize keys & human-readable names ---
  // Split target: utils-geo.js — category key normalization & labels
  function normalizeCategoryKey(k){
    const key = String(k||'standard').toLowerCase().replace(/[^a-z]/g,'');
    const alias = {
      standard:'standard', collaborator:'collaborator', sponsor:'sponsor',
      eventstaff:'eventstaff', foodbeverage:'foodbeverage', activity:'activity'
    };
    return alias[key] || 'standard';
  }
  function catNameForKey(key){
    const m = {
      standard:'Standard', collaborator:'Collaborator', sponsor:'Sponsor',
      eventstaff:'Event Staff', foodbeverage:'Food / Beverage', activity:'Activity'
    };
    return m[ normalizeCategoryKey(key) ] || 'Standard';
  }

  function updateCategoryPill(){
    const el = document.getElementById('categoryText');
    if (!el) return;
    const b = (S.selected && S.booths[S.selected]) ? S.booths[S.selected] : null;
    const key = b ? (b.category||'standard') : (els.category && els.category.value || 'standard');
    el.textContent = catNameForKey(key);
  }

  // #endregion Category helpers: normalize keys & human-readable names ---
  
  // #region Label visibility and layout
  // Split target: draw-overlays.js — label show/hide & zoom-based layout
  // Toggle booth label visibility based on current zoom threshold (LABEL_HIDE_ZOOM from mcpp-config.js)
  function updateLabelVisibility(){
    if (!S || !S.map) return;
    const z = S.map.getZoom();
    const hide = (typeof z === 'number')
      ? (z < (typeof LABEL_HIDE_ZOOM !== 'undefined' ? LABEL_HIDE_ZOOM : 19))
      : false;

    Object.values(S.shapes).forEach(sh => {
      if (!sh || !sh.lab) return;
      // AdvancedMarkerElement content: hide via CSS
      if (sh.labelEl) sh.labelEl.style.display = hide ? 'none' : '';
      // Classic Marker fallback: toggle visibility if supported
      if (typeof sh.lab.setVisible === 'function') sh.lab.setVisible(!hide);
    });
  }

  // Centralize label font/centering styles
  function applyLabelStyles(el, fontPx){
    if (!el) return;
    el.style.fontSize = fontPx + 'px';
    el.style.transform = 'translate(-50%, -50%)';
  }

  // Keep labels centered and scale font as zoom changes
  function updateLabelLayoutForZoom(){
    if (!S || !S.map) return;
    const z = S.map.getZoom() || START_ZOOM;

    // Use config variables for label font scaling (with safe fallbacks)
    const BASE  = (typeof LABEL_FONT_BASE_PX   !== 'undefined') ? LABEL_FONT_BASE_PX   : 12;
    const MINPX = (typeof LABEL_FONT_MIN_PX    !== 'undefined') ? LABEL_FONT_MIN_PX    : 9;
    const MULT  = (typeof LABEL_FONT_SCALE_MULT !== 'undefined') ? LABEL_FONT_SCALE_MULT : 1.0;

    const minFactor = Math.max(0.1, Math.min(1, MINPX / BASE));
    const factor = Math.max(minFactor, Math.min(1.0, (z / START_ZOOM) * MULT));
    const fontPx = Math.round(BASE * factor);

    Object.entries(S.booths).forEach(([id, b]) => {
      const sh = S.shapes[id]; if (!sh) return;

      // Recompute corrected visual center with the current projection
      const pos = getVisualCenterAdjusted(b);

      // Re-anchor the label to the corrected center
      if (sh.lab) setPos(sh.lab, pos);

      // Adjust font size and re-assert centering transform
      applyLabelStyles(sh.labelEl, fontPx);
    });
  }

  function visualCenterForBooth(b){
    if(!S.proj||!S.proj.getProjection) return b.center;
    const proj=S.proj.getProjection(); if(!proj) return b.center;
    const pts=rect(b.center,b.width_feet,b.length_feet,b.rotation_deg);
    let sx=0,sy=0;
    for(const ll of pts){ const p=proj.fromLatLngToContainerPixel(ll); sx+=p.x; sy+=p.y; }
    const cx=sx/pts.length, cy=sy/pts.length;
    return proj.fromContainerPixelToLatLng(new google.maps.Point(cx,cy));
  }
  // Use booth's length to determine knob's orbit radius: (Length/2) + 10 px
  function knobRadiusPxForBooth(b){
     // Use half of the booth's *length* in screen pixels plus a tunable extra.
  // If projection isn't ready, return a safe fallback radius plus the extra.
  if (!S || !S.proj || typeof S.proj.getProjection !== 'function') {
    return KNOB_RADIUS_PX_FALLBACK + KNOB_EXTRA_PX;
  }
  const proj = S.proj.getProjection();
  if (!proj || typeof proj.fromLatLngToContainerPixel !== 'function') {
    return KNOB_RADIUS_PX_FALLBACK + KNOB_EXTRA_PX;
  }

  // Compute the rectangle corners in pixel space using current booth geometry
  const cs = rect(b.center, b.width_feet, b.length_feet, b.rotation_deg)
    .map(ll => proj.fromLatLngToContainerPixel(ll));

  // Opposite edges for the *length* are 1→2 and 3→0; average for stability
  const len12 = Math.hypot(cs[2].x - cs[1].x, cs[2].y - cs[1].y);
  const len30 = Math.hypot(cs[0].x - cs[3].x, cs[0].y - cs[3].y);
  const lengthPx = (len12 + len30) / 2;

  return (lengthPx / 2) + KNOB_EXTRA_PX;
  }
  // Angle (deg, 0 = up, clockwise) on a pixel circle around centerLL, then apply KNOB_SELF_OFFSET_PX
  function knobPosFromAngle(centerLL, angleDeg, radiusPx){
    if(!S.proj||!S.proj.getProjection) return null;
    const proj=S.proj.getProjection(); if(!proj) return null;
    const a  = angleDeg * Math.PI/180;
    const cp = proj.fromLatLngToContainerPixel(centerLL);
    const R  = (typeof radiusPx==='number'?radiusPx:KNOB_RADIUS_PX_FALLBACK);
    // orbit point in pixel space (0° = up)
    let px = cp.x + R * Math.sin(a);
    let py = cp.y - R * Math.cos(a);
    // apply knob’s own nudge (screen pixels)
    px += KNOB_SELF_OFFSET_PX.x||0;
    py += KNOB_SELF_OFFSET_PX.y||0;
    return proj.fromContainerPixelToLatLng(new google.maps.Point(px, py));
  }

  // Apply a pixel offset to a LatLng using the map's projection
  function applyPixelOffset(ll, offset){
    if (!ll || !S.proj || !S.proj.getProjection) return ll;
    const proj = S.proj.getProjection(); if (!proj) return ll;
    const p = proj.fromLatLngToContainerPixel(ll);
    const pt = new google.maps.Point(p.x + (offset?.x||0), p.y + (offset?.y||0));
    return proj.fromContainerPixelToLatLng(pt);
  }
  // Visual center + manual offset (global or per-booth)
  function getVisualCenterAdjusted(b){
    if (!S.proj || typeof S.proj.getProjection !== 'function' || !S.proj.getProjection()) {
      return b.center;
    }
    const vc = visualCenterForBooth(b);
    const off = (PER_BOOTH_OFFSETS && b.center_offset_px) ? b.center_offset_px : CENTER_OFFSET_PX;
    return applyPixelOffset(vc, off);
  }

  // Crosshair debug marker
  function makeCenterDebugEl(){
    const el = document.createElement('div');
    el.style.cssText = 'width:14px;height:14px;transform:translate(-50%,-50%);';
    el.innerHTML = `<svg width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
      <circle cx="7" cy="7" r="6" fill="none" stroke="#d6ff2e" stroke-width="1.5"/>
      <line x1="7" y1="2.2" x2="7" y2="5" stroke="#d6ff2e" stroke-width="1.5"/>
      <line x1="7" y1="9" x2="7" y2="11.8" stroke="#d6ff2e" stroke-width="1.5"/>
      <line x1="2.2" y1="7" x2="5" y2="7" stroke="#d6ff2e" stroke-width="1.5"/>
      <line x1="9" y1="7" x2="11.8" y2="7" stroke="#d6ff2e" stroke-width="1.5"/>
    </svg>`;
    return el;
  }
  function ensureCenterDebugMarker(id, pos){
    if (!SHOW_CENTER_DEBUG) return null;
    const sh = S.shapes[id] || {};
    let m = sh.centerDbg || null;
    if (m) { setPos(m, pos); return m; }
    // create
    if (canAdv) {
      m = new google.maps.marker.AdvancedMarkerElement({ map:S.map, position:pos, content:makeCenterDebugEl(), zIndex:5 });
      if (m.content) m.content.classList.add('mcpp-label-center');
    } else {
      m = new google.maps.Marker({
        map:S.map, position:pos, zIndex:5,
        icon: { path: google.maps.SymbolPath.CIRCLE, scale:4, strokeColor:'#d6ff2e', strokeWeight:2, fillOpacity:0 }
      });
    }
    if (!S.shapes[id]) S.shapes[id] = {};
    S.shapes[id].centerDbg = m;
    if (typeof m.setMap === 'function') m.setMap(S.map);
    return m;
  }

  // #endregion Label visibility and layout
  
  // #region List / CSV =====
  // Split target: ui-list.js — list UI, search, CSV/JSON export
  function listRow(id,b){
    const name=(b.biz&&b.biz.trim())||(b.vendor_name||'');
    const el=document.createElement('div'); el.className='list-item'; el.tabIndex=0;
    const sw=document.createElement('div'); sw.className='legend-swatch';
    const s=CAT[b.category||'standard']||CAT.standard;
    sw.style.background=s.f; sw.style.borderColor=s.s;
    const tx=document.createElement('div');
    tx.innerHTML=`<div><b class='mono'>${id}</b> — ${name||'<em>Unassigned</em>'}</div>`;
    el.appendChild(sw); el.appendChild(tx);
    el.addEventListener('click',()=>{ select(id); S.booths[id]&&S.map&&S.map.panTo(S.booths[id].center); });
    return el;
  }
  function refreshList(){
    if(!els.boothList) return;
    const q=(els.listSearch&&els.listSearch.value||'').toLowerCase();
    els.boothList.innerHTML='';
    Object.entries(S.booths).sort((a,b)=>a[0].localeCompare(b[0])).forEach(([id,b])=>{
      const hay=[id,b.biz||'',b.vendor_name||'',b.phone||'',b.email||'',b.website||'',b.notes||''].join(' ').toLowerCase();
      if(!q||hay.includes(q)) els.boothList.appendChild(listRow(id,b));
    });
  }
  function csv(){
    const rows=[[ "id","lat","lng","width_feet","length_feet","rotation_deg","category","logo_url","business","vendor_name","phone","phone_public","email","email_public","website","notes" ]];
    Object.entries(S.booths).forEach(([id,b])=>rows.push([ id,b.center.lat,b.center.lng,b.width_feet,b.length_feet,b.rotation_deg,b.category||'standard',b.logo_url||'',b.biz||'',b.vendor_name||'',b.phone||'',!!b.phone_public,b.email||'',!!b.email_public,b.website||'',(b.notes||'').replace(/\n/g,' ') ]));
    return rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
  }
  function dl(name,txt,type='text/plain'){
    const blob=new Blob([txt],{type});
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name;
    document.body.appendChild(a); a.click(); a.remove();
  }

  // #endregion List / CSV =====
  
  // #region Draw booth + handle + label =====
  // Split target: draw-overlays.js — booth polygons, labels, rotation knob
  function draw(id){
    const pre=S.shapes[id];
    if(pre){
      pre.poly&&pre.poly.setMap(null);
      if(pre.rot){ pre.rot.map=null; setRotVisibility(pre.rot,false); }
      if(pre.lab){ pre.lab.map=null; }
      if(pre.centerDbg){
        if ('map' in pre.centerDbg) pre.centerDbg.map = null;
        else if (typeof pre.centerDbg.setMap === 'function') pre.centerDbg.setMap(null);
      }
      delete S.shapes[id];
    }
    const b=S.booths[id]; if(!b) return;
    // If the map projection isn't ready yet, defer drawing to avoid off-center label/knob placement
    if (!S || !S.proj || typeof S.proj.getProjection !== 'function' || !S.proj.getProjection()) {
      setTimeout(()=>{ draw(id); }, 30);
      return;
    }
    const assigned=!!(b.biz||b.vendor_name||b.notes||(b.phone||b.email));
    const st=style(b.category||'standard',assigned);
    const sel=(S.selected===id);

    const poly=new google.maps.Polygon({
      paths:rect(b.center,b.width_feet,b.length_feet,b.rotation_deg),
      strokeColor:sel?'#d6ff2e':st.stroke, strokeOpacity:1, strokeWeight:sel?3:1,
      fillColor:st.fill, fillOpacity:.9, clickable:true, draggable:S.isAdmin, zIndex:2
    });
    poly.setMap(S.map);
    poly.addListener('click',()=>{ select(id); S.booths[id]&&S.map&&S.map.panTo(S.booths[id].center); });

    // keep knob/label visually attached while dragging
    poly.addListener('drag',()=>{
      if(!S.isAdmin) return;
      const p=poly.getPath(); let la=0,ln=0;
      for(let i=0;i<p.getLength();i++){ la+=p.getAt(i).lat(); ln+=p.getAt(i).lng(); }
      b.center={lat:la/p.getLength(), lng:ln/p.getLength()};
      const visDragC = getVisualCenterAdjusted(b);
      const RpxDrag  = knobRadiusPxForBooth(b);
      const cwAngle  = ((-b.rotation_deg % 360)+360)%360;
      const followPos = knobPosFromAngle(visDragC, cwAngle, RpxDrag);
      if (S.shapes[id] && S.shapes[id].rot){
        setPos(S.shapes[id].rot, followPos);
      }
      if (S.shapes[id] && S.shapes[id].lab){
        setPos(S.shapes[id].lab, visDragC);
      }
      if (S.shapes[id] && S.shapes[id].centerDbg){
        setPos(S.shapes[id].centerDbg, visDragC);
      }
    });
    poly.addListener('dragend',()=>{
      if(!S.isAdmin) return;
      const p=poly.getPath(); let la=0,ln=0;
      for(let i=0;i<p.getLength();i++){ la+=p.getAt(i).lat(); ln+=p.getAt(i).lng(); }
      b.center={lat:la/p.getLength(), lng:ln/p.getLength()};
      draw(id); save(false);
    });

    // Rotation handle
    const knobEl = makeRotatorContent();
    let rotM;
    const visC0 = getVisualCenterAdjusted(b);
    const Rpx0  = knobRadiusPxForBooth(b);
    const cw0   = ((-b.rotation_deg % 360)+360)%360; // stored CCW -> CW
    const startPos = knobPosFromAngle(visC0, cw0, Rpx0);
    if (canAdv) {
      rotM = new google.maps.marker.AdvancedMarkerElement({ map:S.map, position:startPos, content:knobEl, gmpDraggable:false, zIndex:3 });
    } else {
      rotM = new google.maps.Marker({
        map:S.map, position:startPos, draggable:!!(S.isAdmin&&sel), zIndex:3,
        icon: (typeof ROT_ICON_URL !== 'undefined')
          ? { url: ROT_ICON_URL, scaledSize: new google.maps.Size(22,22), anchor: new google.maps.Point(11,11) }
          : undefined
      });
      rotM.setDraggable(!!(S.isAdmin&&sel));
      rotM.element = { style:{} }; // shim for unified show/hide
    }

    // Pixel-based rotation update
    const updateRotationFromPoint = (pLatLng)=>{
      if(!pLatLng || !S.proj || !S.proj.getProjection) return;
      const proj=S.proj.getProjection(); if(!proj) return;
      const visC = getVisualCenterAdjusted(b);
      const C = proj.fromLatLngToContainerPixel(visC);
      const P = proj.fromLatLngToContainerPixel(pLatLng);
      const vx = P.x - C.x, vy = P.y - C.y;
      let cw = Math.atan2(vx, -vy) * 180 / Math.PI; // 0° = up, clockwise
      cw = (cw + 360) % 360;
      cw = Math.round(cw / SNAP) * SNAP;
      b.rotation_deg = -cw; // store CCW
      poly.setPaths(rect(b.center,b.width_feet,b.length_feet,b.rotation_deg));
      const newVisC = getVisualCenterAdjusted(b);
      const Rpx     = knobRadiusPxForBooth(b);
      const newKnob = knobPosFromAngle(newVisC, cw, Rpx);
      setPos(rotM, newKnob);
      if (S.shapes[id] && S.shapes[id].centerDbg){
        setPos(S.shapes[id].centerDbg, newVisC);
      }
    };

    if (canAdv) {
      const onPointerDown = (evt)=>{
        if (!S.isAdmin || !sel) return;
        try { evt.preventDefault(); evt.stopPropagation(); } catch(_) {}
        S.draggingRot = true; S.draggingBoothId = id;
        S.map.setOptions({ draggable: false });
        if (rotM.content) { rotM.content.style.cursor = 'grabbing'; rotM.content.style.touchAction = 'none'; }
        const mapEl = document.getElementById('map');
        const onMove = (e)=>{
          if (!S.draggingRot || S.draggingBoothId !== id) return;
          if (!S.proj || !S.proj.getProjection) return;
          const proj=S.proj.getProjection(); if(!proj) return;
          const r = mapEl.getBoundingClientRect();
          const pt = new google.maps.Point(e.clientX - r.left, e.clientY - r.top);
          const ll = proj.fromContainerPixelToLatLng(pt);
          updateRotationFromPoint(ll);
        };
        const onUp = ()=>{
          S.draggingRot=false; S.draggingBoothId=null;
          S.map.setOptions({ draggable: true });
          if (rotM.content) rotM.content.style.cursor = 'grab';
          window.removeEventListener('pointermove', onMove, true);
          window.removeEventListener('pointerup', onUp, true);
          window.removeEventListener('mouseup', onUp, true);
          save(false);
        };
        window.addEventListener('pointermove', onMove, true);
        window.addEventListener('pointerup', onUp, true);
        window.addEventListener('mouseup', onUp, true);
      };
      if (rotM.content) {
        rotM.content.addEventListener('pointerdown', onPointerDown, { passive:false });
        rotM.content.style.cursor = 'grab';
        rotM.content.style.touchAction = 'none';
      }
    } else {
      const onRotStart = ()=>{ if (!S.isAdmin || !sel) return; S.draggingRot = true; S.draggingBoothId = id; };
      const onRotDrag  = (e)=>{ if (!S.draggingRot || S.draggingBoothId !== id) return;
        const p = (e && e.latLng) ? e.latLng : (rotM.getPosition ? rotM.getPosition() : null);
        updateRotationFromPoint(p);
      };
      const onRotEnd   = ()=>{ if (!S.draggingRot) return; S.draggingRot=false; S.draggingBoothId=null; save(false); };
      google.maps.event.addListener(rotM, 'dragstart', onRotStart);
      google.maps.event.addListener(rotM, 'drag', onRotDrag);
      google.maps.event.addListener(rotM, 'dragend', onRotEnd);
    }

    // Label at visual center
    const labelEl=document.createElement('div');
    // Center the Advanced Marker content on its anchor
    labelEl.classList.add('mcpp-label-center');
    labelEl.textContent=id;
    labelEl.style.cssText=`color:${sel?'#d6ff2e':'#eaf6f5'};font-weight:700;font-size:12px;text-shadow:0 0 2px rgba(0,0,0,.6);transform:translate(-50%,-50%);`;
    const visLabelC = getVisualCenterAdjusted(b);
    const lab = (canAdv)
      ? new google.maps.marker.AdvancedMarkerElement({map:S.map,position:visLabelC,content:labelEl,zIndex:4})
      : new google.maps.Marker({map:S.map,position:visLabelC,zIndex:4,label:{text:id,color: sel ? '#d6ff2e' : '#eaf6f5', fontWeight:'700', fontSize:'12px'}});

    // Debug crosshair
    const dbgPos = getVisualCenterAdjusted(b);
    const centerDbg = SHOW_CENTER_DEBUG ? ensureCenterDebugMarker(id, dbgPos) : null;
    if (centerDbg && centerDbg.content) {
      centerDbg.content.classList.add('mcpp-label-center');
    }
    if (centerDbg && !centerDbg.map && typeof centerDbg.setMap === 'function') centerDbg.setMap(S.map);

    S.shapes[id]={poly,rot:rotM,lab,labelEl,centerDbg};
    // Ensure rotation handle visibility matches current mode on first draw
    (function enforceInitialRotVisibility(){
      setRotVisibility(rotM, !!(S.isAdmin && S.selected === id));
    })();
  }

  // #endregion Draw booth + handle + label =====
  
  // #region Overlay sync
  // Split target: draw-overlays.js — recompute centers, reposition overlays
  // Recompute and apply corrected visual centers for all overlays (label, center debug, knob)
  function syncOverlayCenters(){
    if (!S.proj || !S.proj.getProjection) return;
    Object.entries(S.booths).forEach(([id,b])=>{
      const sh = S.shapes[id]; if(!sh) return;
      const pos = getVisualCenterAdjusted(b);
      // label
      if (sh.lab) setPos(sh.lab, pos);
      // center debug
      if (sh.centerDbg) setPos(sh.centerDbg, pos);
      // rotation knob
      if (sh.rot){
        const cw = ((-b.rotation_deg % 360)+360)%360;
        const Rpx = knobRadiusPxForBooth(b);
        const kp  = knobPosFromAngle(pos, cw, Rpx);
        setPos(sh.rot, kp);
      }
    });
  }

  // #endregion Overlay sync
  
  // #region Selection / list =====
  // Split target: ui-list.js — selection state & list-panel updates
  function select(id){
    try{
      S.selected=id; const b=S.booths[id]; if(!b) return;
      // Update Booth # in sticky header (supports <span> and legacy <input>)
      if (els.boothId) {
        try {
          if (typeof els.boothId.textContent === 'string') els.boothId.textContent = id;
          if ('value' in els.boothId) els.boothId.value = id;
        } catch(_) {}
      }
      els.widthFeet&&(els.widthFeet.value=b.width_feet);
      els.lengthFeet&&(els.lengthFeet.value=b.length_feet);
      els.rotationDeg&&(els.rotationDeg.value=Math.round(b.rotation_deg||0));
      if (els.category){
        const key = normalizeCategoryKey(b.category||'standard');
        els.category.value = key;
      }
      updateCategoryPill();
      els.logoUrl&&(els.logoUrl.value=b.logo_url||'');
      if (els.logoPreview) {
        const url = (b.logo_url || '').trim();
        els.logoPreview.src = url || LOGO_BADGE_PLACEHOLDER;
        els.logoPreview.style.display = 'block';
        els.logoPreview.setAttribute('draggable', 'false');
      }
      els.biz&&(els.biz.value=b.biz||'');
      els.vendorName&&(els.vendorName.value=b.vendor_name||'');
      els.phone&&(els.phone.value=(S.isAdmin||b.phone_public)?(b.phone||''):'' );
      els.email&&(els.email.value=(S.isAdmin||b.email_public)?(b.email||''):'' );
      els.website&&(els.website.value=b.website||'');
      els.phonePublic&&(els.phonePublic.checked=!b.phone_public);
      els.emailPublic&&(els.emailPublic.checked=!b.email_public);
      els.notes&&(els.notes.value=b.notes||'');

      const phoneRowSel=document.getElementById('phoneRow'), emailRowSel=document.getElementById('emailRow');
      if(!S.isAdmin){ phoneRowSel&&(phoneRowSel.style.display=b.phone_public?'':'none'); emailRowSel&&(emailRowSel.style.display=b.email_public?'':'none'); }
      else { phoneRowSel&&(phoneRowSel.style.display=''); emailRowSel&&(emailRowSel.style.display=''); }

      Object.entries(S.shapes).forEach(([bid,sh])=>{
        const sel=(bid===id);
        const bb=S.booths[bid];
        const assigned=!!(bb.biz||bb.vendor_name||bb.notes||(bb.phone||bb.email));
        const st=style(bb.category||'standard',assigned);
        sh.poly.setOptions({fillOpacity:sel?1:.75,strokeColor:sel?'#d6ff2e':st.stroke,strokeWeight:sel?3:1});
        if (sh.rot) setRotVisibility(sh.rot, !!(S.isAdmin && sel));

        // Compute the corrected visual center once and reuse
        const pos = getVisualCenterAdjusted(bb);

        // Update label color and position to the corrected center
        if (sh.labelEl) sh.labelEl.style.color = sel ? '#d6ff2e' : '#eaf6f5';
        if (sh.lab) setPos(sh.lab, pos);

        // Update center debug marker
        if (sh.centerDbg){
          setPos(sh.centerDbg, pos);
          if (!sh.centerDbg.map && typeof sh.centerDbg.setMap === 'function') sh.centerDbg.setMap(S.map);
        }
      });

      els.editPanel && els.editPanel.classList.remove('hidden');
      showEditor();
      S.map&&S.map.setOptions({keyboardShortcuts:false});
    }catch(err){ console.error('select() failed:',err); showEditor(); }
  }
  function clearSelection(){
    if(!S.selected){ S.map&&S.map.setOptions({keyboardShortcuts:true}); showList(); return; }
    S.selected=null;
    // Clear Booth # in header when no selection
    if (els.boothId) {
      try {
        if (typeof els.boothId.textContent === 'string') els.boothId.textContent = '—';
        if ('value' in els.boothId) els.boothId.value = '';
      } catch(_) {}
    }
    Object.entries(S.shapes).forEach(([bid,sh])=>{
      const bb=S.booths[bid];
      const st=style(bb.category||'standard',!!(bb.biz||bb.vendor_name||bb.notes||(bb.phone||bb.email)));
      sh.rot&&sh.rot.element&&(sh.rot.element.style.display='none');
      sh.poly.setOptions({strokeColor:st.stroke,strokeWeight:1,fillOpacity:.75});
      sh.labelEl&&(sh.labelEl.style.color='#eaf6f5');
      if (sh.centerDbg){
        if ('map' in sh.centerDbg) sh.centerDbg.map = null;
        else if (typeof sh.centerDbg.setMap === 'function') sh.centerDbg.setMap(null);
      }
    });
    S.map&&S.map.setOptions({keyboardShortcuts:true});
    showList();
  }
  function redraw(){
    Object.values(S.shapes).forEach(sh=>{
      sh.poly&&sh.poly.setMap(null);
      if(sh.rot){ sh.rot.map=null; setRotVisibility(sh.rot,false); }
      if(sh.lab){ sh.lab.map=null; }
      if(sh.centerDbg){
        if ('map' in sh.centerDbg) sh.centerDbg.map = null;
        else if (typeof sh.centerDbg.setMap === 'function') sh.centerDbg.setMap(null);
      }
    });
    S.shapes={};
    const B=new google.maps.LatLngBounds();
    Object.entries(S.booths).forEach(([id,b])=>{ draw(id); rect(b.center,b.width_feet,b.length_feet,b.rotation_deg).forEach(ll=>B.extend(ll)); });
    if(!B.isEmpty() && !S.didInitialViewport){
      const prevMin=S.map.get('minZoom');
      S.map.setOptions({ minZoom: START_ZOOM });
      S.map.fitBounds(B,{top:40,bottom:40,left:20,right:20});
      const once=S.map.addListener('idle',()=>{ S.map.setOptions({ minZoom:(prevMin==null?2:prevMin) }); S.didInitialViewport=true; google.maps.event.removeListener(once); });
    }
    refreshList();
    postViewportSync();
    updateCategoryPill();
  }

  // #endregion Selection / list =====
  
  // #region Controls =====
  // Split target: controls.js — DOM wiring, admin/viewer toggles, inputs
  if (els.logoUrl && els.logoPreview){
    els.logoUrl.addEventListener('input', ()=>{
      const url = (els.logoUrl.value||'').trim();
      els.logoPreview.src = url || LOGO_BADGE_PLACEHOLDER;
      els.logoPreview.style.display = 'block';
      if (S.selected && S.booths[S.selected]){
        S.booths[S.selected].logo_url = url;
      }
    });
  }
  els.addBooth&&els.addBooth.addEventListener('click',async()=>{
    if(!S.isAdmin) return;
    const id='T'+(S.seq++), c=S.map.getCenter().toJSON();
    const w=parseInt(els.defWidth&&els.defWidth.value||10,10)||10;
    const l=parseInt(els.defLength&&els.defLength.value||10,10)||10;
    const cat=(els.defCat&&els.defCat.value)||'standard';
    S.booths[id]={id,center:c,width_feet:w,length_feet:l,rotation_deg:0,biz:'',vendor_name:'',phone:'',email:'',website:'',notes:'',category:cat,logo_url:'',phone_public:false,email_public:false};
    draw(id); select(id); await save(false);
  });
  els.duplicateBooth&&els.duplicateBooth.addEventListener('click',async()=>{
    if(!S.isAdmin||!S.selected) return;
    const s=S.booths[S.selected], id='T'+(S.seq++);
    const {lat,dLng}=d2ll(s.center.lat,8*FT,8*FT);
    S.booths[id]={id,center:{lat,lng:s.center.lng+dLng},width_feet:s.width_feet,length_feet:s.length_feet,rotation_deg:s.rotation_deg,category:s.category,biz:'',vendor_name:'',phone:'',email:'',website:'',notes:'',logo_url:'',phone_public:false,email_public:false};
    draw(id); select(id); await save(false);
  });

  els.assign&&els.assign.addEventListener('click',async()=>{
    if(!S.isAdmin||!S.selected) return;
    const b=S.booths[S.selected];
    b.biz=(els.biz.value||'').trim();
    b.vendor_name=(els.vendorName.value||'').trim();
    b.phone=(els.phone.value||'').trim();
    b.email=(els.email.value||'').trim();
    b.website=(els.website.value||'').trim();
    b.notes=(els.notes.value||'').trim();
    b.logo_url=(els.logoUrl.value||'').trim();
    b.phone_public=!els.phonePublic.checked;
    b.email_public=!els.emailPublic.checked;
    b.width_feet=Math.max(1,parseInt(els.widthFeet.value||b.width_feet,10)||b.width_feet);
    b.length_feet=Math.max(1,parseInt(els.lengthFeet.value||b.length_feet,10)||b.length_feet);
    if(els.rotationDeg){ let d=parseFloat(els.rotationDeg.value||b.rotation_deg)||0; d=Math.round(d/10)*10; b.rotation_deg=d; }
    b.category = normalizeCategoryKey(els.category.value||'standard');
    updateCategoryPill();
    draw(S.selected); await save(false);
  });

  els.unassign&&els.unassign.addEventListener('click',async()=>{
    if(!S.isAdmin||!S.selected) return;
    const b=S.booths[S.selected];
    b.logo_url=''; b.biz=''; b.vendor_name=''; b.phone=''; b.email=''; b.website=''; b.notes=''; b.phone_public=false; b.email_public=false;
    if (els.logoPreview){ els.logoPreview.src = LOGO_BADGE_PLACEHOLDER; els.logoPreview.style.display='block'; }
    draw(S.selected); await save(false);
  });

  els.deleteBooth&&els.deleteBooth.addEventListener('click',async()=>{
    if(!S.isAdmin||!S.selected) return;
    const id=S.selected;
    if(!confirm(`Delete booth ${id}?`)) return;
    const sh=S.shapes[id];
    if(sh){
      sh.poly&&sh.poly.setMap(null);
      if(sh.rot){ sh.rot.map=null; setRotVisibility(sh.rot,false); }
      if(sh.lab){ sh.lab.map=null; }
      if(sh.centerDbg){
        if ('map' in sh.centerDbg) sh.centerDbg.map = null;
        else if (typeof sh.centerDbg.setMap === 'function') sh.centerDbg.setMap(null);
      }
      delete S.shapes[id];
    }
    delete S.booths[id];
    S.selected=null; els.boothId&&(els.boothId.value='');
    await save(false); refreshList(); showList();
  });

  els.exportCSV&&els.exportCSV.addEventListener('click',()=>dl('booths.csv',csv()));
  els.exportJSON&&els.exportJSON.addEventListener('click',()=>dl('booths.json',JSON.stringify(S.booths,null,2),'application/json'));

  els.backToList&&els.backToList.addEventListener('click',()=>{ clearSelection(); });
  els.listSearch&&els.listSearch.addEventListener('input',refreshList);

  if (els.category){
    els.category.addEventListener('change', ()=>{
      const key = normalizeCategoryKey(els.category.value||'standard');
      els.category.value = key; // enforce canonical key in the select
      updateCategoryPill();
    });
  }

  document.addEventListener('click',e=>{
    if(els.profileMenu&&!els.profileMenu.contains(e.target)&&e.target!==els.profileBtn){
      els.profileMenu.classList.add('hidden');
    }
  });
  els.profileBtn&&els.profileBtn.addEventListener('click',e=>{
    e.stopPropagation(); els.profileMenu&&els.profileMenu.classList.remove('hidden');
  });

  const loginLogoutBtn = els.loginBtn || els.logoutBtn;
  if (loginLogoutBtn) {
    loginLogoutBtn.addEventListener('click', async () => {
      if (!S.isAdmin) {
        const pin = prompt('Enter admin PIN:');
        if (pin == null) return;
        const r = await fetch('/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin })
        });
        if (r.ok) {
          await who();
          resetToListPanel();
          els.profileMenu && els.profileMenu.classList.add('hidden');
          loginLogoutBtn.textContent = 'Logout';
        } else {
          alert('Invalid PIN');
        }
      } else {
        await fetch('/logout', { method: 'POST' });
        await who();
        resetToListPanel();
        els.profileMenu && els.profileMenu.classList.add('hidden');
        loginLogoutBtn.textContent = 'Login';
      }
    });
  }

  els.locate&&els.locate.addEventListener('click',()=>{
    const q=els.addr&&els.addr.value.trim(); if(!q) return;
    if(!S.geocoder) S.geocoder=new google.maps.Geocoder();
    S.geocoder.geocode({address:q},(res,st)=>{
      if(st==='OK'&&res[0]){
        const vp=res[0].geometry.viewport||new google.maps.LatLngBounds(res[0].geometry.location,res[0].geometry.location);
        const prevMin=S.map.get('minZoom'); S.map.setOptions({minZoom:START_ZOOM});
        S.map.fitBounds(vp,{top:40,bottom:40,left:20,right:20});
        const once=S.map.addListener('idle',()=>{
          S.map.setOptions({minZoom:(prevMin==null?2:prevMin)});
          S.didInitialViewport=true;
          // After fit/zoom completes, re-sync overlays in one place
          postViewportSync();
          google.maps.event.removeListener(once);
        });
      } else alert('Address not found');
    });
  });
  els.fit&&els.fit.addEventListener('click',()=>{
    if(!Object.keys(S.shapes).length) return;
    const B=new google.maps.LatLngBounds();
    Object.values(S.shapes).forEach(sh=>sh.poly.getPath().forEach(ll=>B.extend(ll)));
    const prevMin=S.map.get('minZoom'); S.map.setOptions({minZoom:START_ZOOM});
    S.map.fitBounds(B,{top:40,bottom:40,left:20,right:20});
    const once=S.map.addListener('idle',()=>{
      S.map.setOptions({minZoom:(prevMin==null?2:prevMin)});
      // Re-sync overlays after the fit completes
      postViewportSync();
      google.maps.event.removeListener(once);
    });
  });
  els.toggleType&&els.toggleType.addEventListener('click',()=>{
    const t=S.map.getMapTypeId(); S.map.setMapTypeId(t==='satellite'?'hybrid':'satellite');
  });

  // Keyboard nudges
  document.addEventListener('keydown',e=>{
    if(!S.isAdmin||!S.selected) return;
    const b=S.booths[S.selected];
    const step=(e.shiftKey?5:1); let E=0,N=0,handled=false;
    if(e.key==='ArrowLeft'){E-=step;handled=true;}
    if(e.key==='ArrowRight'){E+=step;handled=true;}
    if(e.key==='ArrowUp'){N+=step;handled=true;}
    if(e.key==='ArrowDown'){N-=step;handled=true;}
    if(handled){
      e.preventDefault();
      const dx=E*FT, dy=N*FT; const {lat,dLng}=d2ll(b.center.lat,dx,dy);
      b.center={lat,lng:b.center.lng+dLng};
      draw(S.selected); save(true);
    }
  });

  // #endregion Controls =====
  
  // #region Map init =====
  // Split target: map-init.js — map creation, OverlayView, initial redraw
  window.initMCPPMap = async function initMCPPMap(){
    try{
      await who(); await load();
      S.map = new google.maps.Map(document.getElementById('map'), {
        center: DEFAULT_CENTER,
        zoom: START_ZOOM,
        mapTypeId:'satellite',
        mapId: hasMapId ? String(window.__MAP_ID__).trim() : undefined,
        gestureHandling:'greedy',
        mapTypeControl:false, streetViewControl:false, fullscreenControl:true,
        rotateControl:false, maxZoom:23, minZoom:18
      });
      if (!hasMapId) {
        try { console.warn('[MCPP] No Map ID detected. Advanced Markers and vector features may be limited. Set window.__MAP_ID__ to a valid Google Cloud Map ID.'); } catch(_) {}
      }

      // OverlayView to access projection
      function Proj(){}; Proj.prototype=new google.maps.OverlayView();
      Proj.prototype.onAdd=function(){}; Proj.prototype.draw=function(){}; Proj.prototype.onRemove=function(){};
      const overlay=new Proj(); overlay.setMap(S.map); S.proj=overlay;
      canAdv = !!(window.google && window.google.maps && window.google.maps.marker && window.google.maps.marker.AdvancedMarkerElement);
      if (!canAdv) {
        try { console.warn('[MCPP] AdvancedMarkerElement not available (missing marker library?). Logo badges and rotation knob HTML fall back gracefully.'); } catch(_) {}
      }
      (function waitForProjectionAndDraw(attempts=0){
        const ready = S.proj && typeof S.proj.getProjection === 'function' && S.proj.getProjection();
        if (ready) {
          redraw(); // single, final first draw once projection exists
          const syncOnce = S.map.addListener('idle', ()=>{ syncOverlayCenters(); google.maps.event.removeListener(syncOnce); });
        } else if (attempts < 40) {
          requestAnimationFrame(() => waitForProjectionAndDraw(attempts+1));
        }
      })();

      // No 45° tilt
      S.map.setTilt(0); S.map.setHeading(0);
      const clampTilt0=()=>{ if(S.map.getTilt()!==0) S.map.setTilt(0); if(S.map.getHeading()!==0) S.map.setHeading(0); };
      // Consolidated zoom_changed handler
      const onZoomChanged = ()=>{
        clampTilt0();
        updateLabelVisibility();
        updateLabelLayoutForZoom();
      };
      S.map.addListener('idle',clampTilt0);
      S.map.addListener('maptypeid_changed',clampTilt0);
      S.map.addListener('zoom_changed', onZoomChanged);

      // Enforce close initial zoom
      const ensureMinZoom = () => {
        if (S.didInitialViewport) return;
        const z = S.map.getZoom();
        if (z < START_ZOOM) S.map.setZoom(START_ZOOM);
        // do not set S.didInitialViewport here; redraw() will mark it after fitBounds
      };
      const initialIdle=S.map.addListener('idle',()=>{ ensureMinZoom(); google.maps.event.removeListener(initialIdle); });

      S.map.addListener('click',()=>{ resetToListPanel(); });

      // Draw booths

      // Optional address fit
      if(window.__DEFAULTS__ && window.__DEFAULTS__.address){
        if(!S.geocoder) S.geocoder=new google.maps.Geocoder();
        S.geocoder.geocode({address:window.__DEFAULTS__.address},(res,st)=>{
          if(st==='OK'&&res[0]){
            const vp=res[0].geometry.viewport||new google.maps.LatLngBounds(res[0].geometry.location,res[0].geometry.location);
            const prevMin=S.map.get('minZoom'); S.map.setOptions({minZoom:START_ZOOM});
            S.map.fitBounds(vp,{top:40,bottom:40,left:20,right:20});
            const onceGeo=S.map.addListener('idle',()=>{
              S.map.setOptions({minZoom:(prevMin==null?2:prevMin)});
              S.didInitialViewport=true;
              requestAnimationFrame(()=>{
                syncOverlayCenters();
                updateLabelVisibility();
                updateLabelLayoutForZoom();
              });
              google.maps.event.removeListener(onceGeo);
            });
          }
        });
      }

      showList();
      updateCategoryPill();
    }catch(err){
      console.error('[MCPP] init failed',err);
      showBootError(err&&err.message?err.message:String(err));
    }
  };

  // #endregion Map init =====
  
  // Fail notice if API hasn’t loaded
  setTimeout(()=>{ if(!window.google || !google.maps){ showBootError('Google Maps failed to load (403 or network). Check API key & restrictions.'); } }, 3500);
  
})();