(() => {
  "use strict";
  // #region MCPP: Vendor Logo Badges (overlay logos on booth centers)
// Split target: badges.js — Advanced Marker logo overlays
// Uses config from mcpp-config.js: SHOW_LOGO_BADGES, LOGO_BADGE_MIN_ZOOM,
// LOGO_BADGE_BASE_PX, LOGO_BADGE_MIN_PX, LOGO_BADGE_MAX_PX, LOGO_BADGE_PLACEHOLDER

(function(){
  if (!window.S) window.S = {};

  // Helper: is AdvancedMarkerElement available?
  function __advAvailable(){
    try {
      return !!(window.google && google.maps && google.maps.marker && google.maps.marker.AdvancedMarkerElement);
    } catch(_) { return false; }
  }

  // Small helpers to reduce repeated style code
  function __badgeNudge(){
    const n = (typeof LOGO_BADGE_NUDGE_PX !== 'undefined' && LOGO_BADGE_NUDGE_PX)
      ? LOGO_BADGE_NUDGE_PX
      : (window.LOGO_BADGE_NUDGE_PX || { x: 0, y: 0 });
    return { x: Number(n.x)||0, y: Number(n.y)||0 };
  }
  function __applyBadgeStyles(el, size){
    if (!el) return;
    el.style.width  = size + 'px';
    el.style.height = size + 'px';
    el.style.position = 'absolute';
    el.style.left = '50%';
    el.style.top  = '50%';
    const n = __badgeNudge();
    el.style.transform = `translate(-50%, -50%) translate(${n.x}px, ${n.y}px)`;
    el.style.transformOrigin = 'center center';
  }
  function __applyBadgeImgStyles(img){
    if (!img) return;
    img.style.width = '100%';
    img.style.height = '100%';
    img.style.objectFit = 'contain';
  }


  // Use same centering logic as booth labels
  function getVisualCenterAdjusted(b) {
    if (!window.S || !S.proj || typeof S.proj.getProjection !== 'function' || !S.proj.getProjection()) {
      return (b && b.center)
        ? new google.maps.LatLng(b.center.lat, b.center.lng)
        : (S.map ? S.map.getCenter() : new google.maps.LatLng(0,0));
    }
    if (typeof window.getVisualCenterAdjusted === 'function') {
      return window.getVisualCenterAdjusted(b);
    }
    return (b && b.center)
      ? new google.maps.LatLng(b.center.lat, b.center.lng)
      : (S.map ? S.map.getCenter() : new google.maps.LatLng(0,0));
  }

  function logoBadgeSizePxForZoom(z) {
    const factor = Math.pow(2, (z - 20) / 2); // gentle growth around 20
    const px = LOGO_BADGE_BASE_PX * factor;
    return Math.max(LOGO_BADGE_MIN_PX, Math.min(LOGO_BADGE_MAX_PX, px));
  }


  function ensureLogoBadgeForBooth(b, id) {
    if (!SHOW_LOGO_BADGES || !S.map) return;
    if (!__advAvailable()) {
      // Classic Marker can’t host HTML content; skip badges gracefully
      destroyLogoBadge(id);
      return;
    }
    // Skip booths that have no actual logo_url (hide/destroy any prior badge)
    if (!b.logo_url || !b.logo_url.trim()) {
      destroyLogoBadge(id);
      return;
    }
    if (!S.logoBadges) S.logoBadges = {};

    const zoom = S.map.getZoom();
    const shouldShow = (zoom >= LOGO_BADGE_MIN_ZOOM);
    const existing = S.logoBadges[id];

    if (existing) {
      if (!shouldShow) { existing.el.style.display = 'none'; return; }
      existing.el.style.display = 'block';
      const size = logoBadgeSizePxForZoom(zoom);
      __applyBadgeStyles(existing.el, size);
      __applyBadgeImgStyles(existing.img);
      existing.marker.position = getVisualCenterAdjusted(b);
      const src = b.logo_url.trim();
      if (existing.img.src !== src) existing.img.src = src;
      return;
    }

    if (!shouldShow) return; // don't create if not visible

    const size = logoBadgeSizePxForZoom(zoom);

    // zero-sized wrapper at the marker anchor; inner element is centered with -50%/-50%
    const wrap = document.createElement('div');
    wrap.style.cssText = 'position:relative;width:0;height:0;pointer-events:none;';

    const el = document.createElement('div');
    el.className = 'booth-logo-badge';
    __applyBadgeStyles(el, size);
    el.style.pointerEvents = 'none';

    const img = document.createElement('img');
    img.alt = 'Vendor logo';
    img.referrerPolicy = 'no-referrer';
    img.loading = 'lazy';
    img.decoding = 'async';
    img.src = b.logo_url.trim();
    __applyBadgeImgStyles(img);

    el.appendChild(img);
    wrap.appendChild(el);

    const marker = __advAvailable() ? new google.maps.marker.AdvancedMarkerElement({
      map: S.map,
      content: wrap,
      position: getVisualCenterAdjusted(b),
      zIndex: 100
    }) : null;
    if (!marker) { return; }

    S.logoBadges[id] = { marker, wrap, el, img };
  }

  function destroyLogoBadge(id) {
    if (!S.logoBadges) return;
    const badge = S.logoBadges[id];
    if (!badge) return;
    try { badge.marker.map = null; } catch(e) {}
    delete S.logoBadges[id];
  }

  function updateAllLogoBadges() {
    if (!SHOW_LOGO_BADGES || !S.map) return;
    // Early exit if Advanced Markers aren't available: clean up and bail
    if (!__advAvailable()) {
      // Clean up any badges created previously and bail
      if (S.logoBadges) {
        Object.keys(S.logoBadges).forEach(destroyLogoBadge);
      }
      return;
    }
    if (!S.logoBadges) S.logoBadges = {};

    const z = S.map.getZoom();
    const hideAll    = z < (typeof LABEL_HIDE_ZOOM !== 'undefined' ? LABEL_HIDE_ZOOM : 19.5);   // < 19.5: no labels, no badges
    const showBadges = z >= (typeof LOGO_BADGE_MIN_ZOOM !== 'undefined' ? LOGO_BADGE_MIN_ZOOM : 20.75); // >= 20.75
    const midBand    = !hideAll && !showBadges;  // 19.5 <= z < 20.75: labels only

    if (S.booths) {
      for (const id in S.booths) {
        const b = S.booths[id];
        if (!b) continue;
        const hasLogo = !!(b.logo_url && b.logo_url.trim());

        if (hideAll) {
          // No labels, no badges
          const sh = S.shapes && S.shapes[id];
          if (sh && sh.labelEl) sh.labelEl.style.display = 'none';
          destroyLogoBadge(id);
          continue;
        }

        if (midBand) {
          // Labels only
          const sh = S.shapes && S.shapes[id];
          if (sh && sh.labelEl) sh.labelEl.style.display = '';
          destroyLogoBadge(id);
          continue;
        }

        // showBadges band (>= 20.75)
        if (hasLogo) {
          // Badge ON, label OFF
          ensureLogoBadgeForBooth(b, id);
          const badge = S.logoBadges[id];
          if (badge) {
            badge.el.style.display = 'block';
            const size = logoBadgeSizePxForZoom(z);
            __applyBadgeStyles(badge.el, size);
            __applyBadgeImgStyles(badge.img);
            badge.marker.position = getVisualCenterAdjusted(b);
          }
          const sh = S.shapes && S.shapes[id];
          if (sh && sh.labelEl) sh.labelEl.style.display = 'none';
        } else {
          // No logo: label ON, no badge
          const sh = S.shapes && S.shapes[id];
          if (sh && sh.labelEl) sh.labelEl.style.display = '';
          destroyLogoBadge(id);
        }
      }
    }

    // Cleanup badges for booths removed from S.booths
    for (const id in S.logoBadges) {
      if (!S.booths || !S.booths[id]) destroyLogoBadge(id);
    }
  }

  // Hook into redraw if present so badges update after geometry/labels
  const __origRedraw = (typeof redraw === 'function') ? redraw : null;
  if (__origRedraw) {
    redraw = function(){
      const r = __origRedraw.apply(this, arguments);
      try { updateAllLogoBadges(); } catch(e) {}
      return r;
    };
  }

  // Bind to map when available
  (function waitForMap(){
    if (SHOW_LOGO_BADGES && window.S && S.map && !S.__logoBadgeBound && __advAvailable()) {
      try {
        S.map.addListener('zoom_changed', updateAllLogoBadges);
        S.map.addListener('idle', updateAllLogoBadges);
        S.__logoBadgeBound = true;
        updateAllLogoBadges();
      } catch(e) {
        setTimeout(waitForMap, 300);
        return;
      }
    } else if (!S || !S.map) {
      setTimeout(waitForMap, 300);
    }
  })();

  // Tiny API for debugging
  window.mcppLogoBadges = {
    refresh: updateAllLogoBadges,
    destroy: function(){
      if (!S.logoBadges) return;
      Object.keys(S.logoBadges).forEach(destroyLogoBadge);
    }
  };
// #endregion MCPP: Vendor Logo Badges (overlay logos on booth centers)
})();
})();