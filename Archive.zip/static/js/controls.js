(() => {
  "use strict";
  // module code here
})();